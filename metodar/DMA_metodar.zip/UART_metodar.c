// Fil: UART_metodar.c
// Datamaskinkonstruksjon H�st 2017 Gruppe A
// Ove Nicolai Dalheim, Jonas Haldorsen, Trond L�vik, Martin Rygg
//---------------------------------------

//---------------------------------------
// Inklusjonar og definisjonar
//---------------------------------------

#include "stm32f30x.h"
#include "stm32f30x_gpio.h"
#include "stm32f30x_rcc.h"
#include "stm32f30x_usart.h"
#include "stm32f30x_misc.h"

//---------------------------------------
// Globale variablar
//---------------------------------------

#include "extern_dekl_globale_variablar.h"

//---------------------------------------
// Funksjonsprototypar
//---------------------------------------


void USART3_oppstart(void);
void USART3_Put(uint8_t ch);
uint8_t USART3_Get(void);
void USART3_skriv(uint8_t ch);
uint8_t USART3_les(void);
//void USART3_skriv_streng(uint8_t *streng);
void USART3_send_dataa(uint16_t adc_mm);
uint16_t motta2 = 0;


// Funksjonsdeklarasjonar for USART2
//----------------------------------------------------------------------------
void USART2_oppstart(void)
{
//  //Deklarasjon av initialiseringsstrukturane.
//    USART_InitTypeDef USART2_InitStructure;
//    USART_ClockInitTypeDef  USART2_ClockInitStructure;
//    NVIC_InitTypeDef NVIC_InitStruct2;
//
//    // USART-delen m� fiksast slik at den virkar her dvs. p� STM32F3-kortet
//    // der en bruker USART2 i staden for USART1 og med nye GPIO-pinnar, sj� manualen
//    // p� stm32f3 disc. shield samt brukarmanualen p� f3-kortet.
//    // Det kan ogs� vera at strukturdefinisjonane er noko endra, sj� stm32f30x_usart.h
//
//    //Slepp til klokka
//    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
//
//    USART_ClockStructInit(&USART2_ClockInitStructure);
//    USART_ClockInit(USART2, &USART2_ClockInitStructure);
//
//    USART2_InitStructure.USART_BaudRate = 115200; //19200;//57600;//19200; //9600;
//    USART2_InitStructure.USART_WordLength = USART_WordLength_8b;
//    USART2_InitStructure.USART_StopBits = USART_StopBits_1;
//    USART2_InitStructure.USART_Parity =  USART_Parity_No ; //USART_Parity_Odd;
//    USART2_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
//    USART2_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
//
//
//    USART2->CR3 |= 0x40;
//    //Legg inn konfigurasjonen i modulen
//    USART_Init(USART2, &USART2_InitStructure);
//
//
//   //GPIO-delen m� fiksast slik at den virkar her dvs. p� STM32F3-kortet
//   //P� STM32F3: GPIO-pinnane PA2 og 3 brukt mot intern USART2-modul
//   //------------------------------------------
//  //Deklarasjon av initialiseringsstrukturen.
//    GPIO_InitTypeDef GPIO_InitStructure_UART2;
//
//  //Slepp foerst til klokka paa GPIOA-modulen
//	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
//
//  //Sett USART2 Tx (PA2) som AlternativFunksjon og "push-pull" (vanleg totempaale)
//    GPIO_InitStructure_UART2.GPIO_Pin = GPIO_Pin_2;
//    GPIO_InitStructure_UART2.GPIO_Mode  = GPIO_Mode_AF;
//    GPIO_InitStructure_UART2.GPIO_Speed = GPIO_Speed_Level_1;
//    GPIO_InitStructure_UART2.GPIO_OType = GPIO_OType_PP;
//
//  //Initialiser, dvs. last ned konfigurasjonen i modulen
//    GPIO_Init(GPIOA, &GPIO_InitStructure_UART2);
//
//  //Knytt pinnen til AF */
//    GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_7);// Sj� stm32f30x_gpio.h
//
//  //Sett USART2 Rx (PA3) som flytande inngang ("input floating")
//    GPIO_InitStructure_UART2.GPIO_Pin = GPIO_Pin_3;
//    GPIO_InitStructure_UART2.GPIO_Mode = GPIO_Mode_AF;
//    GPIO_InitStructure_UART2.GPIO_PuPd  = GPIO_PuPd_NOPULL;
//
//  //Initialiser, dvs. last ned konfigurasjonen i modulen
//    GPIO_Init(GPIOA, &GPIO_InitStructure_UART2);
//
//  //Knytt pinnen til AF */
//  	GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_7);
//
//  	NVIC_InitStruct2.NVIC_IRQChannel = USART2_IRQn;
//  	NVIC_InitStruct2.NVIC_IRQChannelCmd = ENABLE;
//  	NVIC_InitStruct2.NVIC_IRQChannelPreemptionPriority = 0;
//  	NVIC_InitStruct2.NVIC_IRQChannelSubPriority = 0;
//  	NVIC_Init(&NVIC_InitStruct2);
//  	NVIC_EnableIRQ(USART2_IRQn);
//  	USART2->CR1 |= USART_CR1_RXNEIE;
//
//
//  //Aktiver s� USART2
//    USART_Cmd(USART2, ENABLE);
//
//  //Send til slutt her velkomst via UART/USB-modul
//}
//
////void USART1_skriv_streng(uint8_t *streng){
////    while( *streng != 0) {   // Skriv ut ein 0-terminert tekststreng
////    	USART1_skriv(*streng);
////    	streng++;
////    }
////}
//uint8_t USART2_Get(void)
//{
//    while ( USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET)
//        {
//        ;
//        }
//    return (uint8_t)USART_ReceiveData(USART2);
//}
//
//uint8_t USART2_les(void)
//{
//   if ( USART_GetFlagStatus(USART2, USART_FLAG_RXNE) != RESET)
//        {
//	   return (uint8_t)USART_ReceiveData(USART2);
//   }
//   else {
//       return (uint8_t)0x00;
//   }
}

void USART2_skriv(uint8_t data){
    USART_SendData(USART2, (uint8_t) data); //Loop until the end of transmission
    while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET)
        {
        ;
        }
}

void USART2_send_tid16_sensor16_data16x3(void) {
    int16_t data160, data161, data162, data163;
    uint8_t tid0, tid1;
    //TID
    tid0 = tid_10ms;
    tid1 = tid0 >> 4;
    USART2_skriv('T');            // T for tid
    USART2_skriv((uint8_t)(hex2ascii_tabell[(tid1 & 0x0F)]));
    USART2_skriv((uint8_t)(hex2ascii_tabell[(tid0 & 0x0F)]));
    //SENSOR
    data160 = data0;
    data161 = data160 >> 4;
    data162 = data161 >> 4;
    data163 = data162 >> 4;
    USART2_skriv('S');            // S for sensorverdi
    USART2_skriv((uint8_t)(hex2ascii_tabell[(data163 & 0x000F)]));
    USART2_skriv((uint8_t)(hex2ascii_tabell[(data162 & 0x000F)]));
    USART2_skriv((uint8_t)(hex2ascii_tabell[(data161 & 0x000F)]));
    USART2_skriv((uint8_t)(hex2ascii_tabell[(data160 & 0x000F)]));
    //Aks x-retning
	data160 = aks_x_retn;
	data161 = data160 >> 4;
	data162 = data161 >> 4;
	data163 = data162 >> 4;
	USART2_skriv('X');            // X for aks_x_retn
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data163 & 0x000F)]));
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data162 & 0x000F)]));
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data161 & 0x000F)]));
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data160 & 0x000F)]));
	Aks y-retning
	data160 = aks_y_retn;
	data161 = data160 >> 4;
	data162 = data161 >> 4;
	data163 = data162 >> 4;
	USART2_skriv('Y');            // y for aks_y_retn
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data163 & 0x000F)]));
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data162 & 0x000F)]));
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data161 & 0x000F)]));
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data160 & 0x000F)]));
	//Aks z-retning
	data160 = aks_z_retn;
	data161 = data160 >> 4;
	data162 = data161 >> 4;
	data163 = data162 >> 4;
	USART2_skriv('Z');            // Z for aks_z_retn
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data163 & 0x000F)]));
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data162 & 0x000F)]));
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data161 & 0x000F)]));
	USART2_skriv((uint8_t)(hex2ascii_tabell[(data160 & 0x000F)]));
}
void USART2_IRQHandler(void) {
	if (USART2->ISR & USART_FLAG_RXNE){
		teller_usart2++;
		msblsb2 = USART_ReceiveData(USART2);
		if (msblsb2 == 'k') {					// N�r nye data mottas + start
			teller_usart2 = 0;
			tilstand = 1;}

		if (msblsb2 == 's') {		//((msblsb2 == 's')&&(teller_usart2==1));			// N�r nye data mottas + stopp
			tilstand = 0;}

		if (msblsb2 == 'r') {		// Endre referansen
			teller_usart2 = 6;}
//
//		if (teller_usart2 == 1) {data_usart2_temp1 = msblsb;}  	// MSB K_p
//		if (teller_usart2 == 2) {data_usart2_temp2 = msblsb;}
//		if (teller_usart2 == 3) {data_usart2_temp3 = msblsb;}
//		if (teller_usart2 == 4) {data_usart2_temp4 = msblsb;}
//
//			K_p = 	(uint8_t)(data_usart2_temp1);		//Innlesing av K_p er feil.
//					uint32_t('data_usart2_temp1'-'0')*1000 + (('data_usart2_temp2') - '0') * 100;

//					((data_usart2_temp1) - 48) * 1000 +
//					((data_usart2_temp2) - 48) * 100 +
//					((data_usart2_temp3) - 48) * 10 +
//					((data_usart2_temp4) - 48) ;

//		if (teller_usart2 == 3) {data_usart2_temp1 = (msblsb<<8);}	// MSB K_i
//		if (teller_usart2 == 4) { 									// LSB K_i
//			data_usart2_temp2 = (msblsb&0xFF);
//			K_i = data_usart2_temp1|data_usart2_temp2;}
//
//		if (teller_usart2 == 5) {data_usart2_temp1 = (msblsb<<8);}	// MSB K_d
//		if (teller_usart2 == 6) { 									// LSB K_d
//			data_usart2_temp2 = (msblsb&0xFF);
//			K_d = data_usart2_temp1|data_usart2_temp2;}
//
//		if (teller_usart2 == 7) {data_usart2_temp1 = (msblsb<<8);}	// MSB ref_mm
//		if (teller_usart2 == 8) { 									// LSB ref_mm
//			data_usart2_temp2 = (msblsb&0xFF);
//			ref_mm = data_usart2_temp1|data_usart2_temp2;}

}







// Funksjonsdeklarasjonar for USART3
//----------------------------------------------------------------------------
void USART3_oppstart(void)
{
  //Deklarasjon av initialiseringsstrukturane.
    USART_InitTypeDef USART3_InitStructure;
    USART_ClockInitTypeDef  USART3_ClockInitStructure;
    NVIC_InitTypeDef NVIC_InitStruct;

    // USART-delen m� fiksast slik at den virkar her dvs. p� STM32F3-kortet
    // der en bruker USART3 i staden for USART1 og med nye GPIO-pinnar, sj� manualen
    // p� stm32f3 disc. shield samt brukarmanualen p� f3-kortet.
    // Det kan ogs� vera at strukturdefinisjonane er noko endra, sj� stm32f30x_usart.h

    //Slepp til klokka
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

    USART_ClockStructInit(&USART3_ClockInitStructure);
    USART_ClockInit(USART3, &USART3_ClockInitStructure);

    USART3_InitStructure.USART_BaudRate = 				115200; //115200 //19200;//57600;//19200; //9600;
    USART3_InitStructure.USART_WordLength = 			USART_WordLength_8b;
    USART3_InitStructure.USART_StopBits = 				USART_StopBits_1;
    USART3_InitStructure.USART_Parity =  				USART_Parity_No ; //USART_Parity_Odd;
    USART3_InitStructure.USART_Mode = 					USART_Mode_Rx | USART_Mode_Tx;
    USART3_InitStructure.USART_HardwareFlowControl = 	USART_HardwareFlowControl_None;

    USART3->CR3 |= 0x40;

    //Legg inn konfigurasjonen i modulen
    USART_Init(USART3, &USART3_InitStructure);


   //GPIO-delen m� fiksast slik at den virkar her dvs. p� STM32F3-kortet
   //P� STM32F3: GPIO-pinnane PA2 og 3 brukt mot intern USART3-modul
   //------------------------------------------
  //Deklarasjon av initialiseringsstrukturen.
    GPIO_InitTypeDef GPIO_InitStructure_UART3;

  //Slepp foerst til klokka paa GPIOA-modulen
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, ENABLE);

  //Sett USART3 Tx (PD8) som AlternativFunksjon og "push-pull" (vanleg totempaale)
    GPIO_InitStructure_UART3.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure_UART3.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_InitStructure_UART3.GPIO_Speed = GPIO_Speed_Level_1;
    GPIO_InitStructure_UART3.GPIO_OType = GPIO_OType_PP;



  //Initialiser, dvs. last ned konfigurasjonen i modulen
    GPIO_Init(GPIOD, &GPIO_InitStructure_UART3);

  //Knytt pinnen til AF */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource8, GPIO_AF_7);// Sj� stm32f30x_gpio.h

  //Sett USART3 Rx (PD9) som flytande inngang ("input floating")
    GPIO_InitStructure_UART3.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure_UART3.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure_UART3.GPIO_PuPd  = GPIO_PuPd_NOPULL;

  //Initialiser, dvs. last ned konfigurasjonen i modulen
    GPIO_Init(GPIOD, &GPIO_InitStructure_UART3);

  //Knytt pinnen til AF */
  	GPIO_PinAFConfig(GPIOD, GPIO_PinSource9, GPIO_AF_7);

  //Sl� p� globale avbrudd fra USART3
  	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
    NVIC_InitStruct.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStruct);
    NVIC_EnableIRQ(USART3_IRQn);
    //USART3->CR1 |= USART_CR1_RXNEIE;

//  //Aktiver s� USART1
    USART_Cmd(USART3, ENABLE);
//    USART_DMACmd(USART3, USART_DMAReq_Rx, ENABLE);


  //Send til slutt her velkomst via UART/USB-modul
//	USART3_skriv_streng((uint16_t *)"--\nSTM32F3 er klar!\n\r");  // Ny linje og retur til linjestart etterp�.
}


void USART3_IRQHandler(void) {
	if (rx_buffer_fullt==0){
		if(USART_GetFlagStatus(USART3, USART_FLAG_RXNE)!=RESET){
			rx_buffer[rx_buffer_skriveteller] = USART_ReceiveData(USART3);
			rx_buffer_skriveteller++;

			if(rx_buffer_skriveteller == 5){
				rx_buffer_skriveteller = 0;
				rx_buffer_fullt = 1;

			}
		}
	}

}
//		if(USART3->ISR & USART_FLAG_RXNE){
//			data1 = USART_FLAG_RXNE;
//			msblsb = (uint16_t)USART_ReceiveData(USART3);
//			if (CHECK_BIT(msblsb,8)){
//				data_usart3_temp1 = (msblsb<<8)&0xFF00;
//			}
//			if ((msblsb & 0x0100)==0){ //else?
//				data_usart3_temp2 = (msblsb&0x00FF); //data0|((msblsb)&0x00FF);
//				data0 = data_usart3_temp1|data_usart3_temp2;
//				//data0&=0xFFFC;    // 0b1111 1111 1111 1100 Fjerner de 2 minst sign verdiene (st�y)
//				//data0&=0xFFF8;    // 0b1111 1111 1111 1000 Fjerner de 3 minst sign verdiene (st�y)		}
//	}}
//	if (USART3->ISR & USART_FLAG_RXNE){
//		teller_usart3++;
//		msblsb = USART_ReceiveData(USART3);
//		if (msblsb == 'a') {teller_usart3 = 0;} 					// N�r nye data mottas
//
//		if (teller_usart3 == 1) {data_usart3_temp1 = (msblsb<<8)&0xFF00;}  // MSB sensor
//		if (teller_usart3 == 2) { 									// LSB sensor
//			data_usart3_temp2 = (msblsb&0xFF);
//			data0 = 0;
//			data0 = data_usart3_temp1|data_usart3_temp2;}

//		if (teller_usart3 == 3) {data_usart3_temp1 = (msblsb<<8)&0xFF00;}	// MSB aks. x-retning
//		if (teller_usart3 == 4) { 									// LSB aks. x-retning
//			data_usart3_temp2 = (msblsb&0xFF);
//			aks_x_retn = data_usart3_temp1|data_usart3_temp2;}

//		if (teller_usart3 == 5) {data_usart3_temp1 = (msblsb<<8);}	// MSB aks. y-retning
//		if (teller_usart3 == 6) { 									// LSB aks. y-retning
//			data_usart3_temp2 = (msblsb&0xFF);
//			aks_y_retn = data_usart3_temp1|data_usart3_temp2;}
//
//		if (teller_usart3 == 7) {data_usart3_temp1 = (msblsb<<8);}	// MSB aks. z-retning
//		if (teller_usart3 == 8) { 									// LSB aks. z-retning
//			data_usart3_temp2 = (msblsb&0xFF);
//			aks_z_retn = data_usart3_temp1|data_usart3_temp2;}
//	}

//	if(USART3->ISR & USART_FLAG_RXNE){
//		msblsb = (uint16_t)USART_ReceiveData(USART3);
//		if (CHECK_BIT(msblsb,8)){
//			data0temp = (msblsb<<8);
//		}
//		if ((msblsb & 0x0100)==0){ //else?
//			data0temp2 = (msblsb&0xFF); //data0|((msblsb)&0x00FF);
//			data0 = data0temp|data0temp2;
//			//data0&=0xFFFC;    // 0b1111 1111 1111 1100 Fjerner de 2 minst sign verdiene (st�y)
//			//data0&=0xFFF8;    // 0b1111 1111 1111 1000 Fjerner de 3 minst sign verdiene (st�y)
////		}
//	}
//}
////


//    if (USART3->ISR & USART_FLAG_IDLE) {
//
//        USART3->ISR &= ~USART_FLAG_IDLE;
//        DMA_Cmd(DMA1_Channel3,DISABLE);
//    }
//}

uint16_t USART3_Get16(void)
{
    while ( USART_GetFlagStatus(USART3, USART_FLAG_RXNE) == RESET)
        {
        ;
        }
    motta2 = ((uint8_t)USART_ReceiveData(USART3)<<8);

    while ( USART_GetFlagStatus(USART3, USART_FLAG_RXNE) == RESET)
            {
            ;
            }
    motta2 = (uint8_t)USART_ReceiveData(USART3);
    return motta2;
}

void USART3_lesInnData(void){
	if (rx_buffer_fullt==1){		// Dersom lesebufferet er fullt
		data0 = rx_buffer[1]<<8;		//	Sensorverdi 8-MSB
		data0 += rx_buffer[2];			//  Sensorverdi 8-LSB
		aks_x_retn = rx_buffer[3]<<8;	//  Aksellerasjon 8-MSB
		aks_x_retn += rx_buffer[4];		//  Aksellerasjon 8-LSB
		rx_buffer_fullt=0;				//  Kan n� overskrive gamle verdier i rx_buffer[5]
	}
}


